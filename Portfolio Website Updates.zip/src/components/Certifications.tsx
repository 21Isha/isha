import { Award, Zap, Rocket, Globe, Lightbulb, Trophy, Star, Target, BookOpen } from "lucide-react";

export function Certifications() {
  const certifications = [
    {
      title: "Excel Basic Training Certificate",
      organization: "Infosys",
      icon: BookOpen,
      gradient: "from-green-400 to-emerald-400",
      bgGradient: "from-green-900/50 to-emerald-900/50",
      borderColor: "border-green-500/20 hover:border-green-400/50",
      shadowColor: "hover:shadow-green-500/20"
    },
    {
      title: "IoT Certificate",
      organization: "Infosys",
      icon: Zap,
      gradient: "from-blue-400 to-cyan-400",
      bgGradient: "from-blue-900/50 to-cyan-900/50",
      borderColor: "border-blue-500/20 hover:border-blue-400/50",
      shadowColor: "hover:shadow-blue-500/20"
    },
    {
      title: "Be10x Workshop Certificate",
      organization: "Be10x",
      icon: Rocket,
      gradient: "from-purple-400 to-pink-400",
      bgGradient: "from-purple-900/50 to-pink-900/50",
      borderColor: "border-purple-500/20 hover:border-purple-400/50",
      shadowColor: "hover:shadow-purple-500/20"
    },
    {
      title: "IoT Expo Certificate of Participation",
      organization: "Koneru Lakshmaiah Education Foundation",
      icon: Globe,
      gradient: "from-orange-400 to-red-400",
      bgGradient: "from-orange-900/50 to-red-900/50",
      borderColor: "border-orange-500/20 hover:border-orange-400/50",
      shadowColor: "hover:shadow-orange-500/20"
    },
    {
      title: "Design Thinking and Innovation Patent Publishing Certificate",
      organization: "Koneru Lakshmaiah Education Foundation",
      icon: Lightbulb,
      gradient: "from-yellow-400 to-orange-400",
      bgGradient: "from-yellow-900/50 to-orange-900/50",
      borderColor: "border-yellow-500/20 hover:border-yellow-400/50",
      shadowColor: "hover:shadow-yellow-500/20"
    },
    {
      title: "Ideathon Participation Certificate",
      organization: "Koneru Lakshmaiah Education Foundation",
      icon: Trophy,
      gradient: "from-indigo-400 to-purple-400",
      bgGradient: "from-indigo-900/50 to-purple-900/50",
      borderColor: "border-indigo-500/20 hover:border-indigo-400/50",
      shadowColor: "hover:shadow-indigo-500/20"
    },
    {
      title: "ISRO Bharatiya Antariksh Hackathon Certificate of Acknowledgement",
      organization: "ISRO",
      icon: Star,
      gradient: "from-rose-400 to-pink-400",
      bgGradient: "from-rose-900/50 to-pink-900/50",
      borderColor: "border-rose-500/20 hover:border-rose-400/50",
      shadowColor: "hover:shadow-rose-500/20"
    },
    {
      title: "Samsung Solve for Tomorrow Certificate of Participation",
      organization: "Samsung",
      icon: Target,
      gradient: "from-cyan-400 to-blue-400",
      bgGradient: "from-cyan-900/50 to-blue-900/50",
      borderColor: "border-cyan-500/20 hover:border-cyan-400/50",
      shadowColor: "hover:shadow-cyan-500/20"
    },
    {
      title: "Linguaskills B1 Grade Certificate",
      organization: "University of Cambridge",
      icon: Award,
      gradient: "from-teal-400 to-green-400",
      bgGradient: "from-teal-900/50 to-green-900/50",
      borderColor: "border-teal-500/20 hover:border-teal-400/50",
      shadowColor: "hover:shadow-teal-500/20"
    }
  ];

  return (
    <section id="certifications" className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Certifications & Achievements
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications.map((cert, index) => {
              const IconComponent = cert.icon;
              return (
                <div
                  key={index}
                  className={`bg-gradient-to-br ${cert.bgGradient} p-6 rounded-xl border ${cert.borderColor} transition-all duration-300 hover:scale-105 hover:shadow-xl ${cert.shadowColor} group`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-3 bg-gradient-to-r ${cert.gradient} rounded-lg flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-white mb-2 line-clamp-2 group-hover:text-gray-100">
                        {cert.title}
                      </h3>
                      <p className={`text-sm bg-gradient-to-r ${cert.gradient} bg-clip-text text-transparent font-medium`}>
                        {cert.organization}
                      </p>
                    </div>
                  </div>
                  
                  {/* Hover Effect */}
                  <div className={`mt-4 h-1 bg-gradient-to-r ${cert.gradient} transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left rounded-full`}></div>
                </div>
              );
            })}
          </div>

          {/* Summary Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-xl border border-purple-500/20">
              <div className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
                9
              </div>
              <p className="text-gray-300">Total Certificates</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-blue-900/50 to-cyan-900/50 rounded-xl border border-blue-500/20">
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-2">
                4
              </div>
              <p className="text-gray-300">Organizations</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-green-900/50 to-emerald-900/50 rounded-xl border border-green-500/20">
              <div className="text-3xl font-bold bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent mb-2">
                3
              </div>
              <p className="text-gray-300">Hackathons</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-orange-900/50 to-red-900/50 rounded-xl border border-orange-500/20">
              <div className="text-3xl font-bold bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent mb-2">
                B1
              </div>
              <p className="text-gray-300">Cambridge Level</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}