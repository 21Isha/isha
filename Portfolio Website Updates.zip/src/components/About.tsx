import { GraduationCap, Calendar, Award, MapPin } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            About Me
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* About Text */}
            <div className="space-y-6">
              <p className="text-lg text-gray-300 leading-relaxed">
                I'm currently pursuing my B.Tech degree at Koneru Lakshmaiah Education Foundation, 
                where I've been maintaining a strong academic record with a CGPA of 8.6. My journey 
                in technology is driven by curiosity and a passion for innovation.
              </p>
              
              <p className="text-lg text-gray-300 leading-relaxed">
                Beyond academics, I actively participate in hackathons, workshops, and certification 
                programs. I'm particularly interested in artificial intelligence and have gained 
                proficiency in various AI tools and platforms.
              </p>

              <p className="text-lg text-gray-300 leading-relaxed">
                I believe in continuous learning and staying updated with the latest technological 
                advancements. My goal is to contribute meaningfully to the tech industry while 
                developing innovative solutions to real-world problems.
              </p>
            </div>

            {/* Education Details */}
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-6 rounded-xl border border-purple-500/20 hover:border-purple-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-purple-500/20 rounded-full">
                    <GraduationCap className="text-purple-400 w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-semibold text-white">Education</h3>
                </div>
                <div className="space-y-2">
                  <p className="text-purple-300 font-medium">Bachelor of Technology</p>
                  <p className="text-gray-400">Koneru Lakshmaiah Education Foundation</p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-cyan-900/50 to-blue-900/50 p-6 rounded-xl border border-cyan-500/20 hover:border-cyan-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/20">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-cyan-500/20 rounded-full">
                    <Calendar className="text-cyan-400 w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-semibold text-white">Duration</h3>
                </div>
                <div className="space-y-2">
                  <p className="text-cyan-300 font-medium">2024 - 2028</p>
                  <p className="text-gray-400">Currently in 2nd Year</p>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 p-6 rounded-xl border border-green-500/20 hover:border-green-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-green-500/20">
                <div className="flex items-center gap-4 mb-4">
                  <div className="p-3 bg-green-500/20 rounded-full">
                    <Award className="text-green-400 w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-semibold text-white">CGPA</h3>
                </div>
                <div className="space-y-2">
                  <p className="text-green-300 font-medium text-2xl">8.6</p>
                  <p className="text-gray-400">Current Academic Performance</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}