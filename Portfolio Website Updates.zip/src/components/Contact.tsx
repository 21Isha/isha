import { Mail, Github, Linkedin, MapPin, Send, MessageCircle } from "lucide-react";

export function Contact() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Get In Touch
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-start">
            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-white mb-4">Let's Connect!</h3>
                <p className="text-lg text-gray-300 leading-relaxed">
                  I'm always open to discussing new opportunities, innovative projects, 
                  or just having a conversation about technology and AI. Feel free to reach out!
                </p>
              </div>

              <div className="space-y-6">
                {/* Email */}
                <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-purple-900/50 to-pink-900/50 rounded-lg border border-purple-500/20 hover:border-purple-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/20">
                  <div className="p-3 bg-purple-500/20 rounded-full">
                    <Mail className="w-6 h-6 text-purple-400" />
                  </div>
                  <div>
                    <p className="text-gray-300 font-medium">Email</p>
                    <a
                      href="mailto:ishakasarneni@gmail.com"
                      className="text-purple-300 hover:text-purple-200 transition-colors"
                    >
                      ishakasarneni@gmail.com
                    </a>
                  </div>
                </div>

                {/* GitHub */}
                <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-cyan-900/50 to-blue-900/50 rounded-lg border border-cyan-500/20 hover:border-cyan-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/20">
                  <div className="p-3 bg-cyan-500/20 rounded-full">
                    <Github className="w-6 h-6 text-cyan-400" />
                  </div>
                  <div>
                    <p className="text-gray-300 font-medium">GitHub</p>
                    <a
                      href="https://github.com/21Isha/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-300 hover:text-cyan-200 transition-colors"
                    >
                      github.com/21Isha
                    </a>
                  </div>
                </div>

                {/* LinkedIn */}
                <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-pink-900/50 to-rose-900/50 rounded-lg border border-pink-500/20 hover:border-pink-400/50 transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/20">
                  <div className="p-3 bg-pink-500/20 rounded-full">
                    <Linkedin className="w-6 h-6 text-pink-400" />
                  </div>
                  <div>
                    <p className="text-gray-300 font-medium">LinkedIn</p>
                    <a
                      href="#"
                      className="text-pink-300 hover:text-pink-200 transition-colors"
                    >
                      Connect with me
                    </a>
                  </div>
                </div>

                {/* Location */}
                <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-green-900/50 to-emerald-900/50 rounded-lg border border-green-500/20">
                  <div className="p-3 bg-green-500/20 rounded-full">
                    <MapPin className="w-6 h-6 text-green-400" />
                  </div>
                  <div>
                    <p className="text-gray-300 font-medium">Location</p>
                    <p className="text-green-300">India</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 p-8 rounded-xl border border-gray-500/20">
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                <MessageCircle className="w-6 h-6 text-purple-400" />
                Send a Message
              </h3>
              
              <form className="space-y-6">
                <div>
                  <label className="block text-gray-300 mb-2" htmlFor="name">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full p-3 bg-black/50 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors"
                    placeholder="Your Name"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 mb-2" htmlFor="email">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full p-3 bg-black/50 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors"
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 mb-2" htmlFor="message">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full p-3 bg-black/50 border border-gray-600 rounded-lg text-white focus:border-purple-400 focus:outline-none transition-colors resize-none"
                    placeholder="Your message here..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full p-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-purple-500/50 flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}