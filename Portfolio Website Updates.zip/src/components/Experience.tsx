import { Users, Calendar, MapPin, Briefcase } from "lucide-react";

export function Experience() {
  return (
    <section id="experience" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Experience
          </h2>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 to-pink-500"></div>

            {/* Experience Item */}
            <div className="relative pl-20 pb-12">
              {/* Timeline Dot */}
              <div className="absolute left-6 top-6 w-4 h-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full border-4 border-black"></div>
              
              {/* Content */}
              <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 p-8 rounded-xl border border-purple-500/20 hover:border-purple-400/50 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/20">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">Club Member</h3>
                    <h4 className="text-xl text-purple-300 mb-2">KLU CIIE Club</h4>
                  </div>
                  <div className="flex items-center gap-4 text-gray-400">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>August 2025 - Present</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-cyan-400 mt-1 flex-shrink-0" />
                    <p className="text-gray-300">
                      <span className="font-medium text-cyan-300">Koneru Lakshmaiah Education Foundation</span>
                    </p>
                  </div>

                  <div className="flex items-start gap-3">
                    <Briefcase className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                    <div className="text-gray-300">
                      <p className="mb-2">
                        Recently joined the KLU Center for Innovation, Incubation and Entrepreneurship (CIIE) Club, 
                        focusing on fostering innovation and entrepreneurial thinking among students.
                      </p>
                      <ul className="space-y-1 text-sm text-gray-400">
                        <li>• Participating in innovation workshops and entrepreneurship programs</li>
                        <li>• Collaborating with fellow students on innovative projects</li>
                        <li>• Developing skills in project management and team leadership</li>
                        <li>• Contributing to the university's startup ecosystem</li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Users className="w-5 h-5 text-pink-400 mt-1 flex-shrink-0" />
                    <p className="text-gray-300">
                      <span className="font-medium text-pink-300">Skills Developed:</span> Leadership, Innovation Management, 
                      Entrepreneurship, Team Collaboration, Project Planning
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Info */}
          <div className="mt-12 bg-gradient-to-r from-gray-900/50 to-gray-800/50 p-8 rounded-xl border border-gray-500/20">
            <h3 className="text-2xl font-bold text-white mb-4 text-center">Looking Forward</h3>
            <p className="text-lg text-gray-300 text-center max-w-3xl mx-auto">
              Actively seeking internship opportunities and collaborative projects to apply my academic knowledge 
              in real-world scenarios. Open to contributing to innovative startups, tech companies, and research initiatives 
              that align with my interests in AI and technology innovation.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}