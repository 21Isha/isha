import profileImage from 'figma:asset/21cb80dff24b49228bb9eba3fc8076072769f871.png';
import { Github, Mail, Linkedin, Sparkles, Stars } from "lucide-react";

export function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-48 h-48 bg-pink-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
        
        {/* Floating Icons */}
        <Sparkles className="absolute top-20 left-10 text-purple-400 w-6 h-6 animate-bounce" />
        <Stars className="absolute top-40 right-20 text-pink-400 w-8 h-8 animate-bounce delay-1000" />
        <Sparkles className="absolute bottom-40 left-20 text-cyan-400 w-5 h-5 animate-bounce delay-2000" />
      </div>

      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Profile Image */}
          <div className="mb-8">
            <div className="relative inline-block">
              <div className="w-48 h-48 mx-auto rounded-full overflow-hidden border-4 border-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 p-1 bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400">
                <img
                  src={profileImage}
                  alt="Kasaraneni Isha"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <div className="absolute -inset-4 bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 rounded-full blur opacity-30 animate-pulse"></div>
            </div>
          </div>

          {/* Name with Gradient */}
          <h1 className="text-6xl md:text-8xl font-bold mb-4 bg-gradient-to-r from-purple-400 via-pink-400 via-red-400 to-orange-400 bg-clip-text text-transparent animate-pulse">
            Kasaraneni.isha
          </h1>

          {/* Title */}
          <h2 className="text-2xl md:text-3xl text-gray-300 mb-6 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            B.Tech Student & AI Enthusiast
          </h2>

          {/* Bio */}
          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto mb-8 leading-relaxed">
            Second-year B.Tech student at Koneru Lakshmaiah Education Foundation, passionate about technology, 
            artificial intelligence, and innovation. Currently maintaining an impressive 8.6 CGPA while actively 
            participating in hackathons, workshops, and certification programs.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <a
              href="#contact"
              className="px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full hover:from-purple-600 hover:to-pink-600 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/50"
            >
              Get In Touch
            </a>
            <a
              href="https://github.com/21Isha/"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 border-2 border-cyan-400 text-cyan-400 rounded-full hover:bg-cyan-400 hover:text-black transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-400/50"
            >
              View GitHub
            </a>
          </div>

          {/* Social Links */}
          <div className="flex justify-center space-x-6">
            <a
              href="mailto:ishakasarneni@gmail.com"
              className="p-3 border border-purple-400 rounded-full text-purple-400 hover:bg-purple-400 hover:text-black transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-purple-400/50"
            >
              <Mail size={20} />
            </a>
            <a
              href="https://github.com/21Isha/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 border border-cyan-400 rounded-full text-cyan-400 hover:bg-cyan-400 hover:text-black transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-cyan-400/50"
            >
              <Github size={20} />
            </a>
            <a
              href="#"
              className="p-3 border border-pink-400 rounded-full text-pink-400 hover:bg-pink-400 hover:text-black transition-all duration-300 hover:scale-110 hover:shadow-lg hover:shadow-pink-400/50"
            >
              <Linkedin size={20} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}