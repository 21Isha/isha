import { Brain, MessageSquare, Sparkles, Users, Lightbulb, Target } from "lucide-react";

export function Skills() {
  const skillCategories = [
    {
      title: "Soft Skills",
      icon: Users,
      gradient: "from-blue-400 to-cyan-400",
      bgGradient: "from-blue-900/50 to-cyan-900/50",
      borderColor: "border-blue-500/20 hover:border-blue-400/50",
      shadowColor: "hover:shadow-blue-500/20",
      skills: [
        "Communication",
        "Leadership",
        "Problem Solving",
        "Team Collaboration",
        "Time Management",
        "Critical Thinking"
      ]
    },
    {
      title: "AI Tools & Platforms",
      icon: Brain,
      gradient: "from-purple-400 to-pink-400",
      bgGradient: "from-purple-900/50 to-pink-900/50",
      borderColor: "border-purple-500/20 hover:border-purple-400/50",
      shadowColor: "hover:shadow-purple-500/20",
      skills: [
        "ChatGPT",
        "Gemini AI",
        "AI-powered Development",
        "Prompt Engineering",
        "AI Research",
        "Machine Learning Basics"
      ]
    },
    {
      title: "Professional Skills",
      icon: Target,
      gradient: "from-green-400 to-blue-400",
      bgGradient: "from-green-900/50 to-blue-900/50",
      borderColor: "border-green-500/20 hover:border-green-400/50",
      shadowColor: "hover:shadow-green-500/20",
      skills: [
        "Project Management",
        "Research & Analysis",
        "Technical Documentation",
        "Innovation Thinking",
        "Workshop Participation",
        "Hackathon Experience"
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Skills & Expertise
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {skillCategories.map((category, index) => {
              const IconComponent = category.icon;
              return (
                <div
                  key={index}
                  className={`bg-gradient-to-br ${category.bgGradient} p-8 rounded-xl border ${category.borderColor} transition-all duration-300 hover:scale-105 hover:shadow-xl ${category.shadowColor}`}
                >
                  <div className="text-center mb-6">
                    <div className={`inline-flex p-4 bg-gradient-to-r ${category.gradient} rounded-full mb-4`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <h3 className={`text-2xl font-bold bg-gradient-to-r ${category.gradient} bg-clip-text text-transparent`}>
                      {category.title}
                    </h3>
                  </div>

                  <div className="space-y-3">
                    {category.skills.map((skill, skillIndex) => (
                      <div
                        key={skillIndex}
                        className="bg-black/40 p-3 rounded-lg border border-gray-700/50 hover:border-gray-600/70 transition-all duration-300 hover:shadow-md"
                      >
                        <div className="flex items-center gap-3">
                          <Sparkles className={`w-4 h-4 bg-gradient-to-r ${category.gradient} bg-clip-text text-transparent`} />
                          <span className="text-gray-300">{skill}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Additional Skills Section */}
          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-gray-900/50 to-gray-800/50 p-8 rounded-xl border border-gray-500/20">
              <div className="flex items-center justify-center gap-4 mb-6">
                <Lightbulb className="w-8 h-8 text-yellow-400" />
                <h3 className="text-2xl font-bold text-white">Additional Strengths</h3>
              </div>
              <p className="text-lg text-gray-300 max-w-3xl mx-auto">
                Passionate about continuous learning, staying updated with emerging technologies, 
                and applying theoretical knowledge to practical projects. Strong foundation in 
                academic research, workshop facilitation, and collaborative problem-solving.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}