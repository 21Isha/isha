
  # Portfolio Website Updates

  This is a code bundle for Portfolio Website Updates. The original project is available at https://www.figma.com/design/82lO2Vs7yHXgIO009Jo7LD/Portfolio-Website-Updates.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  