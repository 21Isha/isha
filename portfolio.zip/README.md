
  # Portfolio Webpage Design

  This is a code bundle for Portfolio Webpage Design. The original project is available at https://www.figma.com/design/69Gci0wYbUsq7ip7K8Jjbq/Portfolio-Webpage-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  