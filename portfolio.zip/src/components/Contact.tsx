import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Mail, Github, Linkedin, MapPin, Phone } from "lucide-react";

export function Contact() {
  const contactInfo = [
    {
      icon: <Mail className="h-5 w-5" />,
      label: "Email",
      value: "ishakasarneni@gmail.com",
      href: "mailto:ishakasarneni@gmail.com",
      gradient: "from-red-500 to-pink-500"
    },
    {
      icon: <Github className="h-5 w-5" />,
      label: "GitHub",
      value: "21Isha",
      href: "https://github.com/21Isha/",
      gradient: "from-purple-500 to-blue-500"
    },
    {
      icon: <MapPin className="h-5 w-5" />,
      label: "Location",
      value: "Koneru Lakshmaiah Education Foundation",
      href: null,
      gradient: "from-green-500 to-teal-500"
    }
  ];

  return (
    <section id="contact" className="py-16 px-6 bg-gray-900/30">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 bg-gradient-to-r from-pink-400 to-purple-600 bg-clip-text text-transparent">Get In Touch</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            I'm always open to discussing new opportunities, collaborations, 
            or just having a conversation about technology and innovation.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-colors">
              <CardHeader>
                <CardTitle className="text-white">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {contactInfo.map((contact, index) => (
                  <div key={index} className="flex items-center gap-4">
                    <div className={`p-2 bg-gradient-to-r ${contact.gradient} rounded-lg text-white`}>
                      {contact.icon}
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">{contact.label}</p>
                      {contact.href ? (
                        <a 
                          href={contact.href} 
                          target={contact.href.startsWith('http') ? '_blank' : undefined}
                          rel={contact.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                          className="text-white hover:text-purple-400 transition-colors"
                        >
                          {contact.value}
                        </a>
                      ) : (
                        <p className="text-white">{contact.value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:border-pink-500/50 transition-colors">
              <CardHeader>
                <CardTitle className="text-white">Let's Connect</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-gray-400">
                  Whether you're interested in collaborating on a project, discussing 
                  emerging technologies, or exploring opportunities in AI and innovation, 
                  I'd love to hear from you.
                </p>
                
                <div className="space-y-3">
                  <Button className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white" asChild>
                    <a href="mailto:ishakasarneni@gmail.com">
                      <Mail className="mr-2 h-4 w-4" />
                      Send Email
                    </a>
                  </Button>
                  
                  <Button className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white" asChild>
                    <a href="https://github.com/21Isha/" target="_blank" rel="noopener noreferrer">
                      <Github className="mr-2 h-4 w-4" />
                      View GitHub Profile
                    </a>
                  </Button>
                </div>

                <div className="pt-4 border-t border-gray-700">
                  <p className="text-sm text-gray-400 text-center">
                    Available for internships, projects, and collaborative opportunities
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}