import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Calendar, Users, Building } from "lucide-react";

export function Experience() {
  return (
    <section id="experience" className="py-16 px-6 bg-gray-900/50">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 bg-gradient-to-r from-green-400 to-blue-600 bg-clip-text text-transparent">Experience</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Recent involvement in innovation and entrepreneurship activities.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card className="hover:shadow-xl hover:shadow-green-500/20 transition-all duration-300 bg-gray-800/50 border-gray-700 hover:border-green-500/50">
            <CardHeader>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg">
                  <Building className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <CardTitle className="flex items-center gap-2 mb-2 text-white">
                    Club Member
                    <Badge className="bg-gradient-to-r from-green-500 to-teal-500 text-white border-none">Current</Badge>
                  </CardTitle>
                  <p className="text-gray-400 mb-2">KLU CIIE Club</p>
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Calendar className="h-4 w-4" />
                    <span>August 2025 - Present</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-gray-400">
                  Recently joined the KLU CIIE (Center for Innovation, Incubation and Entrepreneurship) Club, 
                  focusing on innovation, entrepreneurship, and collaborative learning opportunities.
                </p>
                
                <div>
                  <h4 className="mb-2 text-white">Key Activities:</h4>
                  <ul className="space-y-1 text-sm text-gray-400">
                    <li>• Participating in innovation workshops and ideation sessions</li>
                    <li>• Collaborating with fellow students on entrepreneurial projects</li>
                    <li>• Engaging in startup ecosystem learning and development</li>
                    <li>• Contributing to club activities and community building</li>
                  </ul>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-gradient-to-r from-green-500 to-blue-500 text-white border-none">Innovation</Badge>
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-none">Entrepreneurship</Badge>
                  <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-none">Team Collaboration</Badge>
                  <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white border-none">Leadership</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="mt-8 text-center">
            <Card className="bg-gray-800/30 border-gray-700">
              <CardContent className="pt-6">
                <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full w-fit mx-auto mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h4 className="mb-2 text-white">Open to Opportunities</h4>
                <p className="text-gray-400">
                  Actively seeking internships, projects, and collaborative opportunities 
                  in technology, AI, and innovation domains.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}