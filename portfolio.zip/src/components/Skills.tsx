import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Brain, MessageSquare, Sparkles } from "lucide-react";

export function Skills() {
  const skillCategories = [
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: "Soft Skills",
      description: "Strong communication and interpersonal abilities",
      skills: ["Communication", "Leadership", "Team Collaboration", "Problem Solving", "Critical Thinking"],
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: <Brain className="h-6 w-6" />,
      title: "AI & Technology Tools",
      description: "Proficient in utilizing cutting-edge AI applications",
      skills: ["ChatGPT", "Gemini AI", "AI-Powered Tools", "Prompt Engineering", "AI Integration"],
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: <Sparkles className="h-6 w-6" />,
      title: "Technical Expertise",
      description: "Strong foundation in various technical domains",
      skills: ["Excel", "IoT", "Design Thinking", "Innovation", "Research"],
      gradient: "from-green-500 to-blue-500"
    }
  ];

  return (
    <section id="skills" className="py-16 px-6 bg-gray-900/50">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">Skills & Expertise</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            A diverse skill set combining technical proficiency with strong soft skills 
            and cutting-edge AI tool expertise.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <Card key={index} className="hover:shadow-xl hover:shadow-purple-500/20 transition-all duration-300 bg-gray-800/50 border-gray-700 hover:border-purple-500/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-white">
                  <div className={`p-2 bg-gradient-to-r ${category.gradient} rounded-lg text-white`}>
                    {category.icon}
                  </div>
                  {category.title}
                </CardTitle>
                <p className="text-sm text-gray-400">{category.description}</p>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <Badge 
                      key={skillIndex} 
                      className={`bg-gradient-to-r ${category.gradient} text-white hover:scale-105 transition-transform`}
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}