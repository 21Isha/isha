import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Download, ExternalLink } from "lucide-react";

export function Hero() {
  return (
    <section className="pt-24 pb-16 px-6 relative overflow-hidden">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl">
                Hi, I'm <span className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 bg-clip-text text-transparent">Kasaraneni Isha</span>
              </h1>
              <h2 className="text-xl lg:text-2xl text-gray-300">
                B.Tech Student | AI Enthusiast | Innovation Explorer
              </h2>
              <p className="text-lg text-gray-400 max-w-lg">
                A passionate B.Tech 2nd year student at Koneru Lakshmaiah Education Foundation, 
                exploring the frontiers of technology, artificial intelligence, and innovation. 
                Currently maintaining a CGPA of 8.6 with a focus on emerging technologies.
              </p>
            </div>
            <div className="flex flex-wrap gap-4">
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white" asChild>
                <a href="#contact">
                  Get In Touch
                </a>
              </Button>
              <Button variant="outline" className="border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white" asChild>
                <a href="https://github.com/21Isha/" target="_blank" rel="noopener noreferrer">
                  View GitHub <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <div className="relative">
              <div className="w-80 h-80 rounded-full overflow-hidden border-4 border-purple-500 shadow-2xl shadow-purple-500/50">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1590563152569-bd0b2dae4418?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBjb2xsZWdlJTIwc3R1ZGVudCUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc1OTg0Nzc0NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Kasaraneni Isha"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full blur-xl opacity-70"></div>
              <div className="absolute -top-4 -left-4 w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full blur-lg opacity-70"></div>
              <div className="absolute top-1/2 -right-8 w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full blur-sm opacity-60"></div>
            </div>
          </div>
        </div>
      </div>
      {/* Background decorative elements */}
      <div className="absolute top-20 left-10 w-2 h-2 bg-purple-500 rounded-full opacity-50"></div>
      <div className="absolute bottom-20 right-20 w-3 h-3 bg-pink-500 rounded-full opacity-40"></div>
      <div className="absolute top-1/3 right-10 w-1 h-1 bg-blue-500 rounded-full opacity-60"></div>
    </section>
  );
}