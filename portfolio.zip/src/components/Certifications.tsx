import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Award, Building, Globe, Rocket, Lightbulb, Users, Languages } from "lucide-react";

export function Certifications() {
  const certifications = [
    {
      title: "Excel Basic Training Certificate",
      issuer: "Infosys",
      icon: <Building className="h-5 w-5" />,
      category: "Technical Skills",
      gradient: "from-blue-500 to-blue-600"
    },
    {
      title: "IoT Certificate",
      issuer: "Infosys",
      icon: <Globe className="h-5 w-5" />,
      category: "Technology",
      gradient: "from-green-500 to-green-600"
    },
    {
      title: "Be10x Workshop Certificate",
      issuer: "Be10x",
      icon: <Lightbulb className="h-5 w-5" />,
      category: "Professional Development",
      gradient: "from-purple-500 to-purple-600"
    },
    {
      title: "IoT Expo Certificate of Participation",
      issuer: "Koneru Lakshmaiah Education Foundation",
      icon: <Globe className="h-5 w-5" />,
      category: "Participation",
      gradient: "from-orange-500 to-orange-600"
    },
    {
      title: "Design Thinking and Innovation Patent Publishing Certificate",
      issuer: "Koneru Lakshmaiah Education Foundation",
      icon: <Lightbulb className="h-5 w-5" />,
      category: "Innovation",
      gradient: "from-pink-500 to-pink-600"
    },
    {
      title: "Ideathon Participation Certificate",
      issuer: "Koneru Lakshmaiah Education Foundation",
      icon: <Users className="h-5 w-5" />,
      category: "Competition",
      gradient: "from-teal-500 to-teal-600"
    },
    {
      title: "ISRO Bharatiya Antariksh Hackathon Certificate of Acknowledgement",
      issuer: "ISRO",
      icon: <Rocket className="h-5 w-5" />,
      category: "Space Technology",
      gradient: "from-indigo-500 to-indigo-600"
    },
    {
      title: "Samsung Solve for Tomorrow Certificate of Participation",
      issuer: "Samsung",
      icon: <Lightbulb className="h-5 w-5" />,
      category: "Innovation Challenge",
      gradient: "from-red-500 to-red-600"
    },
    {
      title: "LinguaSkills B1 Grade Certificate",
      issuer: "University of Cambridge",
      icon: <Languages className="h-5 w-5" />,
      category: "Language Proficiency",
      gradient: "from-yellow-500 to-yellow-600"
    }
  ];

  return (
    <section id="certifications" className="py-16 px-6">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">Certifications & Achievements</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            A comprehensive collection of certifications and achievements showcasing 
            continuous learning and participation in various technical and innovation challenges.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {certifications.map((cert, index) => (
            <Card key={index} className="hover:shadow-xl hover:shadow-purple-500/20 transition-all duration-300 hover:scale-105 bg-gray-800/50 border-gray-700 hover:border-purple-500/50">
              <CardHeader className="pb-3">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg bg-gradient-to-r ${cert.gradient} text-white`}>
                    {cert.icon}
                  </div>
                  <div className="flex-1">
                    <Badge className={`mb-2 text-xs bg-gradient-to-r ${cert.gradient} text-white border-none`}>
                      {cert.category}
                    </Badge>
                    <CardTitle className="text-sm leading-tight text-white">
                      {cert.title}
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-gray-400">{cert.issuer}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-center">
          <Card className="max-w-md bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 justify-center text-white">
                <div className="p-1 bg-gradient-to-r from-yellow-500 to-orange-500 rounded">
                  <Award className="h-5 w-5 text-white" />
                </div>
                Academic Excellence
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1747576686252-ef7fbbde3829?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJ0aWZpY2F0ZXMlMjBhY2hpZXZlbWVudCUyMGdyYWR1YXRpb258ZW58MXx8fHwxNzU5ODQ3MDI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Achievements and certifications"
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <p className="text-gray-400">
                Continuously pursuing excellence through various certification programs 
                and competitive challenges.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}