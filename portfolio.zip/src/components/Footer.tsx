export function Footer() {
  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-8 px-6">
      <div className="container mx-auto">
        <div className="text-center space-y-4">
          <h3 className="bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 bg-clip-text text-transparent">Kasaraneni Isha</h3>
          <p className="text-gray-400">
            B.Tech Student | AI Enthusiast | Innovation Explorer
          </p>
          <div className="flex justify-center space-x-6 text-sm">
            <a href="#about" className="text-gray-400 hover:text-cyan-400 transition-colors">About</a>
            <a href="#skills" className="text-gray-400 hover:text-purple-400 transition-colors">Skills</a>
            <a href="#certifications" className="text-gray-400 hover:text-blue-400 transition-colors">Certifications</a>
            <a href="#contact" className="text-gray-400 hover:text-pink-400 transition-colors">Contact</a>
          </div>
          <div className="pt-4 border-t border-gray-800">
            <p className="text-sm text-gray-500">
              © 2025 Kasaraneni Isha. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}