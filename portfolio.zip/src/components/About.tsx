import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { GraduationCap, Calendar, Award } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-16 px-6 bg-gray-900/30">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl mb-4 bg-gradient-to-r from-cyan-400 to-blue-600 bg-clip-text text-transparent">About Me</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Passionate about technology and innovation, I'm constantly exploring new horizons 
            in artificial intelligence and emerging technologies.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <Card className="bg-gray-800/50 border-gray-700 hover:border-cyan-500/50 transition-colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <div className="p-1 bg-gradient-to-r from-cyan-500 to-blue-500 rounded">
                    <GraduationCap className="h-5 w-5 text-white" />
                  </div>
                  Education
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="text-white">Bachelor of Technology (B.Tech)</h4>
                  <p className="text-gray-400">Koneru Lakshmaiah Education Foundation</p>
                  <div className="flex items-center gap-4 mt-2">
                    <Badge className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white border-none">
                      <Calendar className="h-3 w-3 mr-1" />
                      2024 - 2028
                    </Badge>
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-none">
                      <Award className="h-3 w-3 mr-1" />
                      CGPA: 8.6
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700 hover:border-purple-500/50 transition-colors">
              <CardHeader>
                <CardTitle className="text-white">Academic Excellence</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Currently in my 2nd year with a strong academic record, maintaining a CGPA of 8.6. 
                  Actively involved in various technical competitions, hackathons, and innovation challenges 
                  that have shaped my problem-solving abilities and technical expertise.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-center">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1707927438677-592d30e1262a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwcHJvZ3JhbW1pbmclMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzU5ODQ3MDI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Technology workspace"
                className="rounded-lg shadow-lg max-w-md w-full border-2 border-purple-500/30"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-500/20 to-transparent rounded-lg"></div>
              <div className="absolute -bottom-6 -right-6 w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full blur-lg opacity-70"></div>
              <div className="absolute -top-6 -left-6 w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full blur-md opacity-70"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}