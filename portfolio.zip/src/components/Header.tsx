import { Button } from "./ui/button";
import { Github, Linkedin, Mail } from "lucide-react";

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-gray-800">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <div>
          <h3 className="bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">Kasaraneni Isha</h3>
        </div>
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#about" className="text-gray-300 hover:text-purple-400 transition-colors">About</a>
          <a href="#skills" className="text-gray-300 hover:text-blue-400 transition-colors">Skills</a>
          <a href="#certifications" className="text-gray-300 hover:text-cyan-400 transition-colors">Certifications</a>
          <a href="#experience" className="text-gray-300 hover:text-green-400 transition-colors">Experience</a>
          <a href="#contact" className="text-gray-300 hover:text-pink-400 transition-colors">Contact</a>
        </nav>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" className="text-gray-300 hover:text-purple-400 hover:bg-purple-500/10" asChild>
            <a href="https://github.com/21Isha/" target="_blank" rel="noopener noreferrer">
              <Github className="h-4 w-4" />
            </a>
          </Button>
          <Button variant="ghost" size="sm" className="text-gray-300 hover:text-blue-400 hover:bg-blue-500/10" asChild>
            <a href="mailto:ishakasarneni@gmail.com">
              <Mail className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </header>
  );
}